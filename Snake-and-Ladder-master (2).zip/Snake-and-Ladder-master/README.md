# Snake-and-Ladder
[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)                  [![Python 3.6](https://img.shields.io/badge/python-3.7-blue.svg)](https://www.python.org/downloads/release/python-360/)

[![PROJECT](https://img.shields.io/badge/AK-Made%20by%20AK-success)](https://github.com/ArvindAROO/)


A simple snake and ladder game using python
This was last semester's project.
A simple command line interface snake and ladder game using python

The file LegacyCode.py is the deprecated and not so good version of the game
But it is still in GitHub because it was my first project ever and I just wanted it in my legacy online

If you want a good working version, use snakeandladder.py
Hope you all enjoy it
Thank you,
With love,
<./AK>
